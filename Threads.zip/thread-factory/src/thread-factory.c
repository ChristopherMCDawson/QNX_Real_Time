#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h>

void sigusr1_handler(int sig);

sig_atomic_t usr1Happened = 0;
sig_atomic_t signal_num = 0;
sem_t *sem;

void* childThread(void *arg) {
	printf("Child thread %d created\n", pthread_self());
	while (1) {
		int x = sem_wait(sem); /* Return-value for sem_wait. Successful = 0 */
		if (x != 0) { /* If unsuccessful, then print error */
			perror("\nUnsuccessful sem-wait\n");
		}
		/* After receiving sem_post from Thread_Wake */
		printf("Child thread %d unblocked\n", pthread_self());
		/* Sleep to add delay */
		sleep(5);
	}
	return NULL;
}

int main(void) {
	struct sigaction usr1;
	usr1.sa_handler = sigusr1_handler; /* Setting the handler for SIGUSR1 */
	usr1.sa_flags = 0; /* or SA_RESTART */
	sigemptyset(&usr1.sa_mask);
	/* Checking whether sigemptyset returned 0 or -1 */
	/* sigaction() function allows the calling process to examine
	 * and/or specify the action to be associated with a specific signal. */
	if (sigaction(SIGUSR1, &usr1, NULL) == -1) {
		/* If sigemptyset returned -1 */
		perror("sigaction");
		exit(1);
	}

	int nThreads;
	printf("Enter the number of threads to create: \n");
	scanf("%d", &nThreads);
	sem = sem_open("semP", O_CREAT, S_IWOTH, 0);
	pthread_attr_t attr;
	int i;
	for (i = 0; i < nThreads; i++) {
		pthread_attr_init(&attr);
		pthread_create(NULL, &attr, &childThread, NULL);
		pthread_attr_destroy(&attr);
	}
	while (usr1Happened != 1) {
	}
	int semC = sem_close(sem);
	if (semC == -1) {
		perror("Sem_Close was not executed");
	}

	int semD = sem_destroy(sem);
	if (semD == -1) {
		perror("Sem_Destroy was not executed");
	}
	/* Exit-Success on completion of the program */
	return EXIT_SUCCESS;
}

void sigusr1_handler(int sig) {
	usr1Happened = 1;
	signal_num = sig;
	printf("\nPID = %d: Thread-factory received USR1.", getpid());
	printf("\nPID = %d: Thread-factory Exiting.\n", getpid());
}

