Title: Assignment 2 Metronome
Author: Christopher Decarie-Dawson Deca0058@algonquinlive.com

Status: 
	- Project runs and behaves as expected
	- There are no run time errors and all requirements are within the
	scope of Assginment 2 of CST8244.

Known Issues:  No known issues to report
Expected Grade: A+ ? 
