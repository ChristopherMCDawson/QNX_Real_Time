Assignment 1

Author: Christopher Decarie-Dawson ( Deca0058@algonquinlive.com )

Status: ~Works , tho I do have an error with output I couldn't trace.

Expected grade A , maybe please.